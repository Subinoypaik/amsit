
$(document).ready(function() {

// Wow //
    new WOW().init();


//  Sticky  //
    $(window).scroll(function () {
        if ($(this).scrollTop() > 20) {
            $('.header').addClass("sticky");
        } else {
            $('.header').removeClass("sticky");
        }
    });


//  Search-bar-top  //
$(document).ready(function () {
    $("#ser-input").focus(function () {
        $('.search-full-view').addClass("search-normal-screen");
    });
    $("#search-close").click(function () {
        $('.search-full-view').removeClass("search-normal-screen");
    });
});



    // client //
    $('.client').owlCarousel({
        loop: true,
        dots: false,
        center: false,
        margin:20,
        responsiveClass: true,
        autoplay: true,
        autoplayTimeout: 2000,
        autoplayHoverPause: true,
        responsive:{
            0:{
                items:2,
                nav:false,
                dots: false,
            },
            600:{
                items:3,
                nav:false,
                dots: false,
            },
            1200:{
                items:6,
                nav:false,
                dots: false,
                margin:20,
            }
        }
    });

    // service //
    $('.box-service').owlCarousel({
        loop: true,
        dots: false,
        center: false,
        margin:20,
        responsiveClass: true,
        autoplay: true,
        autoplayTimeout: 6000,
        autoplayHoverPause: true,
        responsive:{
            0:{
                items:1,
                nav:false,
                dots: false,
            },
            600:{
                items:3,
                nav:false,
                dots: false,
            },
            1200:{
                items:4,
                nav:false,
                dots: false,
                margin:20,
            }
        }
    });


 //  tools //
 $('.tools').owlCarousel({
    loop: true,
    dots: false,
    center: false,
    margin:20,
    responsiveClass: true,
    autoplay: true,
    autoplayTimeout: 6000,
    autoplayHoverPause: true,
    responsive:{
        0:{
            items:3,
            nav:false,
            dots: false,
        },
        600:{
            items:3,
            nav:false,
            dots: false,
        },
        1200:{
            items:6,
            nav:false,
            dots: false,
        }
    }
});

    if($(window).width() <= 991){
        $('.right-nav li.nav-item a.quick-link').each(function(){
            $(this).removeAttr('data-target');
            $(this).removeAttr('data-toggle');
        });
        };
    
});

