<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>:: AmsIt ::</title>
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="Quickdev">
<link rel="canonical" href="https://example.com"/>
<link href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css" rel="stylesheet">
<!-----Font ---->
<!----fontawesome css ---->
<link href="<?php echo get_template_directory_uri(); ?>/font-awesome/css/font-awesome.css" rel="stylesheet">
<!----------owl----------->
<link href="<?php echo get_template_directory_uri(); ?>/css/owl.carousel.min.css" rel="stylesheet">
<!----ANIMATION CSS----->
<link href="<?php echo get_template_directory_uri(); ?>/wow/css/animate.css" rel="stylesheet">

 <script src="<?php echo get_template_directory_uri(); ?>/js/modernizr.js"></script>
 <!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script type="text/javascript" src="js/respond.min.js"></script>
<![endif]-->
<!--- Custom ---->
<link href="<?php echo get_template_directory_uri(); ?>/css/scss/style.css" rel="stylesheet">
<link href="<?php echo get_template_directory_uri(); ?>/css/responsive.css" rel="stylesheet">
<?php wp_head()?>
</head>
<body>
<header>
<!----header-part---->
<section  class="header header-part">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand" href="#">
                            AmsIt
                        </a>
                        <div class="mobile-view">
                            <ul class="right-nav">
                                <li class="nav-item"><a href="tel:91+ 0000 000 000" class="quick-link"  id="removedata" data-toggle="modal" data-target="#myModal">quick contact</a></li>
                                <li class="nav-item">
                                    <form>
                                        <a  class="ser-input" id="ser-input" href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/search.png" class="img-fluid" alt="seach-bar" title="search"  loading="lazy"></a>
                                        <div class="seach-bar">
                                            <div class="search-full-view">
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Search...">
                                                    <button class=" btn input-group-addon"><i class="fa fa-search" aria-hidden="true"></i></button>
                                                </div>
                                                <button class="btn btn-close" id="search-close"> <img src="<?php echo get_template_directory_uri(); ?>/images/clear-close-cancel-white.png" alt="close" title="close"  loading="lazy"></button>
                                            </div>
                                        </div>
                                    </form>
                                </li>

                            </ul>
                        </div>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                            <span class="navbar-toggler-icon"></span>
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <!-- <ul class="navbar-nav nav-left">
                                <li class="nav-item">
                                    <a class="nav-link active" href="index.html">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="about.html"> about us</a>
                                </li>

                                <li class="nav-item dropdown">
                                    <a class="nav-link" href="#" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Our services</a>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="mobile-application.html">Mobile application</a>
                                            <a class="dropdown-item" href="web-development.html">Web development</a>
                                            <a class="dropdown-item" href="ux-designs.html">UX designs</a>
                                            <a class="dropdown-item" href="consulting.html">Consulting</a>
                                            <a class="dropdown-item" href="CMS-development.html">CMS development</a>
                                            <a class="dropdown-item" href="hire-our-team.html">Hire our  Team</a>
                                            <a class="dropdown-item" href="maintenance-and-support.html">Maintenance and Support</a>
                                          </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link " href="blog.html">Blog</a>
                                </li>

                             
                                
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.html">Contact us</a>
                                </li>
                            </ul> -->
                            

<?php wp_nav_menu(array('theme_location'=>'header-menu',"container"=>"ul","menu_class"=>"navbar-nav", "depth"=> 2 , 'walker' => new WP_Bootstrap_Navwalker()));?>
                           
                        </div>

                    </nav>
                </div>
            </div>
        </div>
    </section>
</header>
<!------menu  bar end---->