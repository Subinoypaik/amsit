<?php
add_theme_support('title-tag');
// Logo
    add_theme_support('custom-header');
    // thumbnails
    add_theme_support( 'post-thumbnails' );

    // nav menu
require ('class-wp-bootstrap-navwalker.php');
function register_my_menus() {
    register_nav_menus(
        array(
            'header-menu' => __( 'Header Menu' ),
            'socal-link' => __('Socal link'),
            'menu'              => 'primary',
            'theme_location'    => 'header-menu',
            'container'         => 'div',
           
            'container_class'   => '',
            'container_id'      => '',
            'menu_class'        => 'navbar-nav mr-auto',
        )
    );
}
   add_action( 'init', 'register_my_menus' );


// mobile // email
   add_action('customize_register', 'theme_contact_customizer');
   function theme_contact_customizer($wp_customize) {
       $wp_customize->add_section( 'contact_settings_section', array(
           'title' => 'Contact Info'
       ) );
       $wp_customize->add_setting( 'address', array(
           'default' => '',
       ) );
       $wp_customize->add_control( 'address', array(
           'label'       => 'Address',
           'description' => 'Add details here',
           'section'     => 'contact_settings_section',
           'type'        => 'textarea',
       ) );
       $wp_customize->add_setting( 'phone-number', array(
           'default' => '',
       ) );
       $wp_customize->add_control( 'phone-number', array(
           'label'       => 'Phone Number',
           'description' => 'Add details here',
           'section'     => 'contact_settings_section',
           'type'        => 'text',
       ) );
       $wp_customize->add_setting( 'email', array(
           'default' => '',
       ) );
       $wp_customize->add_control( 'email', array(
           'label'       => 'Email',
           'description' => 'Add details here',
           'section'     => 'contact_settings_section',
           'type'        => 'email',
       ) );
   
       $wp_customize->add_setting( 'footer-title', array(
           'default' => '',
       ) );
       $wp_customize->add_control( 'footer-title', array(
           'label'       => 'footer Title',
           'description' => 'Add details here',
           'section'     => 'contact_settings_section',
           'type'        => 'text',
       ) );
       $wp_customize->add_setting( 'footer-text', array(
           'default' => '',
       ) );
       $wp_customize->add_control( 'footer-text', array(
           'label'       => 'footer Text',
           'description' => 'Add details here',
           'section'     => 'contact_settings_section',
           'type'        => 'textarea',
       ) );
       $wp_customize->add_setting( 'fax', array(
           'default' => '',
       ) );
       $wp_customize->add_control( 'fax', array(
           'label'       => 'fax',
           'description' => 'Add details here',
           'section'     => 'contact_settings_section',
           'type'        => 'text',
       ) );
   }


   // footer widget
register_sidebar( array(
    'name' => __( 'Footer1', 'demolition' ),
    'id' => 'footer1',
    'description' => __( 'Add widgets here to appear in your footer.', 'demolition' ),
    'before_widget' => ' <ul class="footer-tittle">',
    'after_widget' => '</ul>',
    'before_title' => '<h4>',
    'after_title' => '</h4>',
));
register_sidebar( array(
    'name' => __( 'Footer2', 'demolition' ),
    'id' => 'footer2',
    'description' => __( 'Add widgets here to appear in your footer.', 'demolition' ),
    'before_widget' => ' <ul class="quick-links">',
    'after_widget' => '</ul>',
    'before_title' => '<h4>',
    'after_title' => '</h4>',
));
register_sidebar( array(
    'name' => __( 'social_link', 'demolition' ),
    'id' => 'social_link',
    'description' => __( 'Add widgets here to appear in your footer.', 'demolition' ),
    'before_widget' => ' <ul class="footer-social">',
    'after_widget' => '</ul>',
    'before_title' => '<h4>',
    'after_title' => '</h4>',
));


// acf  //
if( function_exists('acf_add_options_page') ) {
    acf_add_options_page(array(
        'page_title' 	=> 'Theme General Settings',
        'menu_title'	=> 'Theme Settings',
        'menu_slug' 	=> 'theme-general-settings',
        'capability'	=> 'edit_posts',
        'redirect'		=> false
    ));
    acf_add_options_sub_page(array(
        'page_title' 	=> 'Theme Header Settings',
        'menu_title'	=> 'Header',
        'parent_slug'	=> 'theme-general-settings',
    ));
    acf_add_options_sub_page(array(
        'page_title' 	=> 'Theme Footer Settings',
        'menu_title'	=> 'Footer',
        'parent_slug'	=> 'theme-general-settings',
    ));
    acf_add_options_sub_page(array(
        'page_title' 	=> 'Theme sidebar Settings',
        'menu_title'	=> 'Sidebar',
        'parent_slug'	=> 'theme-general-settings',
    ));
}

//For Custom Post blog_box:-

$labels = array(
    'name'               => _x('post2', 'post type general name', 'your-plugin-textdomain' ),
    'singular_name'      => _x( 'post2', 'post type singular name', 'your-plugin-textdomain' ),
    'menu_name'          => _x( 'post2', 'admin menu', 'your-plugin-textdomain' ),
    'name_admin_bar'     => _x( 'post2', 'add new on admin bar', 'your-plugin-textdomain' ),
    'add_new'            => _x( 'Add New post2', 'book', 'your-plugin-textdomain' ),
    'add_new_item'       => __( 'Add New post2', 'your-plugin-textdomain' ),
    'new_item'           => __( 'New post2', 'your-plugin-textdomain' ),
    'edit_item'          => __( 'Edit bpost2', 'your-plugin-textdomain' ),
    'view_item'          => __( 'View post2', 'your-plugin-textdomain' ),
    'all_items'          => __( 'All post2', 'your-plugin-textdomain' ),
    'search_items'       => __( 'Search post2', 'your-plugin-textdomain' ),
    'parent_item_colon'  => __( 'Parent post2:', 'your-plugin-textdomain' ),
    'not_found'          => __( 'No post2 found.', 'your-plugin-textdomain' ),
    'not_found_in_trash' => __( 'No post2 found in Trash.', 'your-plugin-textdomain' )
);

$args = array(
    'labels'             => $labels,
    'description'        => __( 'Description.', 'your-plugin-textdomain' ),
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => true,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'post2' ),
    'capability_type'    => 'post',
    'has_archive'        => true,
    'hierarchical'       => false,
    'menu_position'      => null,
    'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
);

register_post_type( 'post2', $args );


?>