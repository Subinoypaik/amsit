
<?php
/*
 * Template Name: about us
 *
 * */ 
?>


<?php get_header();?>


<main>
<!----inner------>
<section class="inner-banner d-flex  justify-content-center text-center" style="background: url(<?php echo get_template_directory_uri(); ?>/images/contact-us.jpg);">
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-8 ml-auto mr-auto">
                    <h1>About us</h1>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
                        Adipisci, sed numquam fugit quas consequatur itaque ipsam.</p>
            </div>
        </div>
    </div>
</section>
<!-----About us------>
<section id="section-01" class="about-text section-wrap">
    <div class="container">
        <div class="row">
        <?php $tests = get_field('about_start');?>
            <?php foreach ($tests as $about_top):
                if($about_top):
                    ?>
            <div class="col-lg-8 ml-auto mr-auto">
                <div class="text-box">
                    <h2><?php echo $about_top['heading'];?></h2>
                    <p><?php echo $about_top['text'];?></p>
                        <div class="btn-new animated fadeInUp mt-3">
                            <a class="btn common-btn" href="<?php echo $about_top['btn']['url'];?>">
                                <div class="effect"></div>
                                <span><?php echo $about_top['btn_text'];?></span>
                            </a>
               
                </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="imagebox">
                    <img src="<?php echo $about_top['images'];?>" class="img-fluid"  loading="lazy" title="about Ams" alt="abc">
                </div>
                
            </div>
            <?php endif; endforeach;?>
        </div>
    </div>
</section>
<!---- why us------>
<section id="section-02" class="why-us">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="heading">
                    <h6> Lorem dolor sit amet</h6>
                    <h2> Why us</h2>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="box-part">
                    <ul class="d-flex flex-wrap">
                        <li>
                            <img src="<?php echo get_template_directory_uri(); ?>/images/project2.svg" class="img-fluid" loading="lazy" alt="image" title="Modern UI/UX">
                            <div class="content">
                                <h3>Superior User-Experience Design</h3>
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
                            </div>
                        </li>
                        <li>
                            <img src="<?php echo get_template_directory_uri(); ?>/images/project.svg" class="img-fluid" loading="lazy" alt="images" title="SEO-Friendly">
                           
                            <div class="content">
                                <h3>Security Checklist</h3>
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
                            </div>
                        </li>
                        <li>
                            <img src="<?php echo get_template_directory_uri(); ?>/images/project.svg" class="img-fluid" alt="project03" title="odern UI/UX">
                           
                            <div class="content">
                                <h3>Modern UI/UX</h3>
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
                                    
                            
                            </div>
                        </li>
                        <li>
                            <img src="<?php echo get_template_directory_uri(); ?>/images/project2.svg" class="img-fluid" alt="have" title="Have An Idea" loding="lazy">
                          
                            <div class="content">
                                <h3>On-Time Delivery</h3>
                                
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!---pax---->
<section  id="section-03" class="paralax-about">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="image-pax">
                    <h3>Lorem ipsume vel nostrum fugit exercitationem<br/> culpa consequatur est!</h3>
                </div>
            </div>
        </div>
    </div>
</section>
<!---team------>
<section class="team section-wrap" id="section-04">
    <div class="container">
        <div class="row">
        <div class="col-lg-12">
                <div class="heading">
                    <h6> With Our team</h6>
                    <h2>Our team</h2>
                </div>
        </div>
        <?php $tests = get_field('team_box');?>
            <?php foreach ($tests as $team):
                if($team):
                    ?>
            <div class="col-lg-4">
                <div class="box-team">
                    <div class="team-img">
                    <img src="<?php echo $team['image'];?>" class="img-fluid"  loading="lazy" title="about Ams" alt="abc">
                     </div> 
                     <div class="contant">
                        <div class="heading-team d-flex justify-content-between">
                            <h2><?php echo $team['name'];?></h2>
                            <h3><?php echo $team['category'];?></h3>
                         </div>
                         <div class="social-link">
                            <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                        </div>
                     </div>
                </div>
            </div>
            <?php endif; endforeach;?>
        </div>
    </div>
</section>

</main>


<?php get_footer();?>