<!-----footer part-->
<footer>
    <div class="footer-area fix">
      
        <div class="footer-caption wow fadeInRight" data-wow-delay=".6s">
            
            <div class="footer-menu ">
                <div class="single-menu">
                    <div class="single-menu1">
                        <div class="single-footer-caption mb-50">
                            <div class="footer-tittle">
                                <h4>Contact</h4>
                                <div class="footer-pera">
                                    
                                    <ul>
                                        <li>Address:<?php echo get_theme_mod('address'); ?>
                                            
                                          </li>
                                          <li> Phone: <?php echo get_theme_mod('phone-number'); ?> </li>
                                       
                                        <li>  Email: <?php echo get_theme_mod('email'); ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="single-menu2">
                        <div class="single-footer-caption mb-50">
                            <div class="footer-tittle">
                               <?php dynamic_sidebar('footer1');?>
                                <!-- <ul>
                                    <li><a href="#">Home</a></li>
                                    <li><a href="#"> About</a></li>
                                    <li><a href="#"> terms and conditions</a></li>
                                    <li><a href="#">Contact</a></li>

                                </ul> -->
                               
                            </div>
                        </div>
                    </div>
                    <div class="single-menu3">
                        <div class="single-footer-caption mb-50">
                            <div class="footer-tittle">
                                <!-- <h4>Services</h4>
                                <ul>
                                    <li><a href="#">Mobile Application</a></li>
                                    <li><a href="#"> Web Application</a></li>
                                    <li><a href="#">Coustom Website</a></li>
                                    <li><a href="#">Cms</a></li>
                                    
                                </ul> -->
                                <?php dynamic_sidebar('footer2');?>
                            </div>
                        </div>
                    </div>
                    <div class="single-menu4">
                        <div class="single-footer-caption">
                             <div class="footer-tittle">
                            <?php dynamic_sidebar('social_link');?>
                                <!-- <h4>Social</h4>
                              
                                <div class="footer-social">
                                    <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                    <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                    <a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                                </div> -->
                            </div> 
                           
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright pt-40">
                <p>@Developed By <a href="#">Ams</a> </p>
            </div>
        </div>
    </div>


    <!-- The Modal -->
<div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <!-- Modal body -->
        <div class="modal-body">
            <h2>Contact Us</h2>
            <form>
                <div class="form-group">
                    <input type="text" placeholder="Name" class="form-control">
                </div>
                <div class="form-group">
                    <input type="email" placeholder="Email id" class="form-control">
                </div>
                <div class="form-group">
                    <input type="text" placeholder="Phone" class="form-control">
                </div>
                <div class="form-group">
                    <textarea class="form-control" placeholder="Type your comment..."></textarea>
                </div>
                <div class="form-group">
                    <button class="btn w-100 quick-link">Submit</button>
                </div>
            </form>
        </div>
      </div>
    </div>
  </div>

<!---JS --->
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery-3.4.0.min.js"></script>

<script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/popper.min.js"></script>
<!----wow ---->
<script src="<?php echo get_template_directory_uri(); ?>/wow/js/wow.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/wow/js/wow.min.js"></script>
<!---owl---->
<script src="<?php echo get_template_directory_uri(); ?>/js/owl.carousel.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/tilt.jquery.min.js"></script>

<!----CUSTOM JS---->
<script src="<?php echo get_template_directory_uri(); ?>/js/custom.js"></script>
   <?php wp_footer()?>
</body>
</html>