<?php get_header();?>

<!----inner------>
<section class="inner-banner d-flex  justify-content-center text-center">
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-8 ml-auto mr-auto">
                    <h1>Blog details</h1>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Adipisci, sed numquam fugit quas consequatur itaque ipsam.

                    </p>
            </div>
        </div>
    </div>
</section>

<!-----Blog-details----->
<section class="blog-details blog-area section-wrap">
    <div class="container">
      <div class="row">
          <div class="col-md-8 col-xs-12">
                 <div class="blog-inner-area">
                    
                        <div class="blog">
                        <?php if(have_posts()):while(have_posts()):the_post();?>
                            <div class="imageblog">
                               <img src="<?php echo get_the_post_thumbnail_url();?>" class="embed-responsive" alt="blogimage" title="blog1" loading="lazy">
                               <p class="date">22<span>May</span></p>
                            </div>
               
                           <div class="contant-blog">
                               <div class="d-flex title-part">
                                <h3><?php the_title();?></h3>
                                 <span><?php the_author();?></span>
                               </div>
                             
                               <p><?php the_content();?></p>
                           </div>
                           <?php endwhile;endif;?>
                        
                        <div class="comments">
                            <div class="comments-title">
                                <h3><?php echo  get_comments_number(); ?> Comments</h3>
                            </div>
                            <?php
                    $comments = get_comments( array( 'post_id' => $post->ID ) );
                    foreach($comments as $comment){
                        $date= $comment->comment_date;
                        $datetime = new DateTime($date);
                        ?>
                            <div class="media-all">
                                <div class="media">
                                    <div class="media-left">
                                        <img src="<?php echo get_avatar_url( $comment->comment_author_email,60); ?>" class="embed-responsive" alt="blogimage" title="blog1" loading="lazy">
                                    </div>
                                    <div class="media-body">
                                    <div class="media-heading">
                                        <a href="#"><?php echo $comment->comment_author;?></a>
                                        <a href="#"><?php echo $datetime->format('M d, Y');?></a>
                                    </div>
                                        <div class="comment-reply">
                                            <p><?php echo $comment->comment_content;?></p>
                                        </div>
                        
                                    </div>
                                </div>
                                
                            </div>
                            <?php }?>

                    
                            
                        </div>
                        <div class="comment-area">
                            <div class="comment-title">
                                <!-- <h3 class="mb-3">Post your Comments</h3> -->
                            </div>
                            <?php comment_form();?>
                        </div>
                           </div>
                        
                       
                        
                    
                 </div>
          </div>
          <div class="col-md-4 col-xs-12">
              <div class="sidebar-area">
                  <form>
                    <div class="form-group d-flex">
                        <input type="text" class="form-control" placeholder="Start serching...">
                        <button class="btn-primary">
                            <i class="fa fa-search" aria-hidden="true"></i>
                        </button>
                      </div>
                  </form>
                  
                  <div class="sidebar-category">
                      <h4>Categories</h4>
                    
                      <ul>
                      <?php
                              $categories = get_categories();
                                        foreach($categories as $category){
                                            ?>
<?php // echo' <li><a href=" ' . get_category_link($category->term_id) . ' ">' . $category->name . '</a>'</li>'?>
<?php  echo' <a href=" ' . get_category_link($category->term_id) . ' ">' . $category->name . '</a>';?>


<?php  }?>
                      </ul>
                  </div>
                  <div class="recent-post sidebar-category">
                      <h4>Recent Post</h4>
                      <div class="side-area mb-3">
                          <div class="left-area">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/solution.jpg" class="embed-responsive" alt="blogimage" title="blog1" loading="lazy">
                          </div>
                          <div class="right-area">
                              <a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a>
                              <h5>May 15, 2021</h5>
                          </div>
                      </div>
                      
                      <div class="side-area">
                        <div class="left-area">
                          <img src="<?php echo get_template_directory_uri(); ?>/images/woman.jpg" class="embed-responsive" alt="blogimage" title="blog1" loading="lazy">
                        </div>
                        <div class="right-area">
                            <a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a>
                            <h5>May 15, 2021</h5>
                        </div>
                    </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
  </section>
<?php get_footer();?>