


<?php get_header();?>

<!----inner------>
<section class="inner-banner d-flex  justify-content-center text-center">
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-8 ml-auto mr-auto">
                    <h1>Blog</h1>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Adipisci, sed numquam fugit quas consequatur itaque ipsam.

                    </p>
            </div>
        </div>
    </div>
</section>

<!-----Blog------>
<section id="" class="blog-area section-wrap">
    <div class="container">
        <div class="row flex-lg-row ">
           <!-- <div class="col-lg-6">
            <div class="blog">
               
                <div class="imageblog">
                   <img src="images/banner-3.jpg" class="embed-responsive" alt="blogimage" title="blog1"  loading="lazy">
                   <p class="date">22<span>May</span></p>
                </div>
   
               <div class="contant-blog">
                   <h3>Blog Title Here</h3>
                   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                        Accusamus adipisci dignissimos eveniet fuga, fugit iusto laudantium nisi nobis.</p>
               </div>
               
                  <div class="arrowbtn">
                       <ul>
                           <li>    <a href="blog-details.html">
                               Read More 
                               <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                               viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                          <g>
                              <g>
                                  <path d="M508.875,248.458l-160-160c-4.167-4.167-10.917-4.167-15.083,0c-4.167,4.167-4.167,10.917,0,15.083l141.792,141.792
                                      H10.667C4.771,245.333,0,250.104,0,256s4.771,10.667,10.667,10.667h464.917L333.792,408.458c-4.167,4.167-4.167,10.917,0,15.083
                                      c2.083,2.083,4.813,3.125,7.542,3.125c2.729,0,5.458-1.042,7.542-3.125l160-160C513.042,259.375,513.042,252.625,508.875,248.458z
                                      "/>
                              </g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                          <g>
                          </g>
                             </svg>
                           
                             </a>
                           </li>
                             <li>
                                 <a href="#">
                                   <svg id="Capa_1" enable-background="new 0 0 511.072 511.072" height="512" viewBox="0 0 511.072 511.072" width="512" xmlns="http://www.w3.org/2000/svg"><g id="Speech_Bubble_48_"><g><path d="m74.39 480.536h-36.213l25.607-25.607c13.807-13.807 22.429-31.765 24.747-51.246-36.029-23.644-62.375-54.751-76.478-90.425-14.093-35.647-15.864-74.888-5.121-113.482 12.89-46.309 43.123-88.518 85.128-118.853 45.646-32.963 102.47-50.387 164.33-50.387 77.927 0 143.611 22.389 189.948 64.745 41.744 38.159 64.734 89.63 64.734 144.933 0 26.868-5.471 53.011-16.26 77.703-11.165 25.551-27.514 48.302-48.593 67.619-46.399 42.523-112.042 65-189.83 65-28.877 0-59.01-3.855-85.913-10.929-25.465 26.123-59.972 40.929-96.086 40.929zm182-420c-124.039 0-200.15 73.973-220.557 147.285-19.284 69.28 9.143 134.743 76.043 175.115l7.475 4.511-.23 8.727c-.456 17.274-4.574 33.912-11.945 48.952 17.949-6.073 34.236-17.083 46.99-32.151l6.342-7.493 9.405 2.813c26.393 7.894 57.104 12.241 86.477 12.241 154.372 0 224.682-93.473 224.682-180.322 0-46.776-19.524-90.384-54.976-122.79-40.713-37.216-99.397-56.888-169.706-56.888z"/></g></g></svg>
                                   <span> 3 Comments </span>
                               </a>
                             </li>
                       </ul>
                   </div>
               </div>
           </div> -->
           <?php
                    $argc = array(

                        'post_type' =>  'post ' ,
                    );
                    $text = new WP_Query($argc);
                    if($text->have_posts()): while($text->have_posts()): $text->the_post();

                        ?>
           <div class="col-lg-6">
                <div class="blog">
                
                <div class="imageblog">
                    <img src="<?php echo get_the_post_thumbnail_url();?>" class="embed-responsive" alt="blogimage" title="blog1"  loading="lazy">
                    <p class="date"><?php the_date('j '); ?> <?php echo '<span>'.get_the_time( 'F').'</span>' ; ?></p>
                </div>

                <div class="contant-blog">
                    <h3><?php the_title();?></h3>
                    <p><?php the_content();?></p>
                </div>
                
                <div class="arrowbtn">
                        <ul>
                            <li>  <a href="<?php the_permalink();?>">
                                Read More 
                                <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                        <g>
                            <g>
                                <path d="M508.875,248.458l-160-160c-4.167-4.167-10.917-4.167-15.083,0c-4.167,4.167-4.167,10.917,0,15.083l141.792,141.792
                                    H10.667C4.771,245.333,0,250.104,0,256s4.771,10.667,10.667,10.667h464.917L333.792,408.458c-4.167,4.167-4.167,10.917,0,15.083
                                    c2.083,2.083,4.813,3.125,7.542,3.125c2.729,0,5.458-1.042,7.542-3.125l160-160C513.042,259.375,513.042,252.625,508.875,248.458z
                                    "/>
                            </g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                        <g>
                        </g>
                            </svg>
                            
                            </a>
                            </li>
                            <li>
                                <a href="#">
                                    <svg id="Capa_1" enable-background="new 0 0 511.072 511.072" height="512" viewBox="0 0 511.072 511.072" width="512" xmlns="http://www.w3.org/2000/svg"><g id="Speech_Bubble_48_"><g><path d="m74.39 480.536h-36.213l25.607-25.607c13.807-13.807 22.429-31.765 24.747-51.246-36.029-23.644-62.375-54.751-76.478-90.425-14.093-35.647-15.864-74.888-5.121-113.482 12.89-46.309 43.123-88.518 85.128-118.853 45.646-32.963 102.47-50.387 164.33-50.387 77.927 0 143.611 22.389 189.948 64.745 41.744 38.159 64.734 89.63 64.734 144.933 0 26.868-5.471 53.011-16.26 77.703-11.165 25.551-27.514 48.302-48.593 67.619-46.399 42.523-112.042 65-189.83 65-28.877 0-59.01-3.855-85.913-10.929-25.465 26.123-59.972 40.929-96.086 40.929zm182-420c-124.039 0-200.15 73.973-220.557 147.285-19.284 69.28 9.143 134.743 76.043 175.115l7.475 4.511-.23 8.727c-.456 17.274-4.574 33.912-11.945 48.952 17.949-6.073 34.236-17.083 46.99-32.151l6.342-7.493 9.405 2.813c26.393 7.894 57.104 12.241 86.477 12.241 154.372 0 224.682-93.473 224.682-180.322 0-46.776-19.524-90.384-54.976-122.79-40.713-37.216-99.397-56.888-169.706-56.888z"/></g></g></svg>
                                    <span> <?php echo  get_comments_number(); ?> Comments </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div> 
          </div> 
        <?php endwhile;endif;?>
    </div>
   
   
        

            </div>
</div>

</section>

<?php get_footer();?>